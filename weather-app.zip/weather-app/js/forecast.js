const API_KEY = '558ea8ad3b77ae7b42985f124235a2f9';
const BASE_URL = 'http://api.openweathermap.org/data/2.5/forecast'
const units = {
    fahren: 'imperial',
    celcius: 'metric',
    default: 'standard'
};

const getForecast = async(cityName) => {
    const URL = BASE_URL + `?q=${cityName}&appid=${API_KEY}&units=${units.celcius}`;
    const res = await fetch(URL);
    if(res.ok){
        const data = await res.json();
        return data;
    }
    throw new Error(res.status);
}

// getForecast('Mumbai').then((data) => {
//     console.log(data);
// });